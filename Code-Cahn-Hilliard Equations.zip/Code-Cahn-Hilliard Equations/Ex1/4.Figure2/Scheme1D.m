% Figure1_1D_MassEnergy.m
% Figure 1: Time history of total mass M(t) and discrete energy E_h(phi^n)
% 1D Cahn-Hilliard equation on Omega = [0, 2*pi] with periodic BC
% Initial condition: phi(x,0) = 0.5 + 0.1*rand(x), rand(x) ~ U[-1,1]
% Parameters: eps = 0.05, J = 512, tau = 1e-3, T = 50, beta = 2
% Eighth-order compact CN scheme, FFT-based fixed-point iteration

clc; clear; close all;
format long e

%% Parameters
eps_v = 0.05;
beta  = 2;
L     = 2*pi;
J     = 512;
h     = L/J;
x     = (0:J-1)'*h;
T     = 50;
tau   = 1e-3;
Nt    = round(T/tau);

% Eighth-order compact coefficients
a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

%% Eigenvalues of L_h
k = (0:J-1)';
lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

% Fourier symbol of the coefficient of phi^{n+1}
A0 = -0.5 + beta/2;
c0_hat = 1/tau - lambda .* (A0 - (eps_v^2/2)*lambda);

%% Initial condition
rand('state', 20240101);
phi_n   = 0.5 + 0.1*(2*rand(J,1) - 1);
phi_nm1 = phi_n;

%% Preallocation
M_vals = zeros(Nt+1,1);
E_vals = zeros(Nt+1,1);

%% Initial mass and energy
M_vals(1) = h*sum(phi_n);
Lphi_0 = real(ifft(lambda .* fft(phi_n)));
E_vals(1) = h*sum(0.25*(phi_n.^2 - 1).^2) ...
          + (eps_v^2*h/2)*sum((-Lphi_0).*phi_n);

%% Time stepping
max_iter = 20;
tol = 1e-12;
tic;

for n = 1:Nt
    % Predictor
    if n == 1
        phi_new = phi_n;
    else
        phi_new = 2*phi_n - phi_nm1;
    end

    % Known part of the RHS
    Lphi_n = real(ifft(lambda .* fft(phi_n)));
    known  = - (eps_v^2/2)*Lphi_n ...
             - 0.5*phi_n.^3 - 0.5*phi_n ...
             - beta*phi_n + (beta/2)*phi_nm1;
    Lknown = real(ifft(lambda .* fft(known)));

    % Fixed-point iteration
    for iter = 1:max_iter
        Lquad = real(ifft(lambda .* fft( (3/2)*phi_n.^2 .* phi_new )));
        rhs_phys = phi_n/tau + Lknown + Lquad;
        rhs_hat  = fft(rhs_phys);
        phi_new_hat  = rhs_hat ./ c0_hat;
        phi_new_iter = real(ifft(phi_new_hat));

        if max(abs(phi_new_iter - phi_new)) < tol
            phi_new = phi_new_iter;
            break;
        end
        phi_new = phi_new_iter;
    end

    phi_nm1 = phi_n;
    phi_n   = phi_new;

    % Record mass and energy
    M_vals(n+1) = h*sum(phi_n);
    Lphi = real(ifft(lambda .* fft(phi_n)));
    E_vals(n+1) = h*sum(0.25*(phi_n.^2 - 1).^2) ...
                + (eps_v^2*h/2)*sum((-Lphi).*phi_n) ...
                + (beta/4)*h*sum((phi_n - phi_nm1).^2);

    if mod(n, 10000) == 0
        fprintf('  step %d / %d, elapsed = %.2f s\n', n, Nt, toc);
    end
end

elapsed = toc;
fprintf('CPU time = %.2f s\n', elapsed);

%% Report key quantities
fprintf('max|M(t) - M(0)| = %.4e\n', max(abs(M_vals - M_vals(1))));
fprintf('E(0) = %.8e\n', E_vals(1));
fprintf('E(T) = %.8e\n', E_vals(end));

%% Plot
%% Plot
% ��ϡ��ֻȡ t = 0, 5, 10, ..., 50 ��Ӧ������
step  = round(5/tau);              % = 5000
idx   = 1:step:(Nt+1);             % 11 ������
t_sel = (idx-1)'*tau;              % 0,5,...,50
M_sel = M_vals(idx);
E_sel = E_vals(idx);

% ����ƫ��ͼ
figure(1); clf;
set(gcf, 'Color', 'w');
plot(t_sel, abs(M_sel - M_sel(1)), 'b-o', 'LineWidth', 2, 'MarkerSize', 5);
xlabel('t', 'FontSize', 12);
ylabel('|M_h(\phi^n)-M_h(\phi^0)|', 'FontSize', 12);
set(gca, 'FontSize', 11);
set(gca, 'XTick', 0:5:50);
xlim([0, 50]);
ylim([-1e-13, 1e-13]);
grid on;

% ����ͼ���������ᣩ
figure(2); clf;
set(gcf, 'Color', 'w');
semilogy(t_sel, E_sel, 'r-o', 'LineWidth', 2, 'MarkerSize', 5);
xlabel('t', 'FontSize', 12);
ylabel('E_h(\phi^n)', 'FontSize', 12);
set(gca, 'FontSize', 11);
set(gca, 'XTick', 0:5:50);
xlim([0, 50]);
grid on;
