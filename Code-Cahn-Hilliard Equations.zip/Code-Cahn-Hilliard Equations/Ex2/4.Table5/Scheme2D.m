% CH2D_Mass_Energy.m
% ��� 2D CH ���̵�����������ɢ����
% ����: [0,1]^2, ���ڱ߽�
% eps = 0.5, beta = 2, h = 0.01, tau = 1e-3, T = 50
% ��ֵ: phi(x,y,0) = 0.5 + 0.1*sin(2*pi*x)*sin(2*pi*y)

clc; clear; close all;
format long e

%% ����
eps_v = 0.05;
beta  = 2;
L     = 1;
h     = 0.02;
tau   = 1e-3;
T     = 10;

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

J = round(L/h);
h = L/J;
x = (0:J-1)'*h;
y = (0:J-1)'*h;
[X, Y] = meshgrid(x, y);

% �˽׽�����������ֵ
k = (0:J-1)';
lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda_1d = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

% ��ά����ֵ (������)
lambda_x = lambda_1d';
Lambda = repmat(lambda_x, J, 1) + repmat(lambda_1d, 1, J);

% �⻬��ֵ
phi_n   = 0.5 + 0.1*sin(2*pi*X).*sin(2*pi*Y);
phi_nm1 = phi_n;

% ��¼ʱ��
T_save = [0,0.5,1,2,3,5,7,10];
n_save = round(T_save/tau);
n_save(1) = 0;

% �洢
M_vals = zeros(size(T_save));
E_vals = zeros(size(T_save));

% �����ʼʱ�̵�����������
M_vals(1) = h^2 * sum(sum(phi_n));
Lphi_0 = real(ifft2(Lambda .* fft2(phi_n)));
E_vals(1) = h^2 * sum(sum(0.25*(phi_n.^2 - 1).^2)) ...
          + (eps_v^2/2) * h^2 * sum(sum((-Lphi_0) .* phi_n));

%% ʱ���ƽ�
Nt = round(T/tau);
max_iter = 20;
tol = 1e-12;
tic;

for n = 1:Nt
    if n == 1
        phi_new = phi_n;
    else
        phi_new = 2*phi_n - phi_nm1;
    end

    Lphi_n = real(ifft2(Lambda .* fft2(phi_n)));
    known = - (eps_v^2/2)*Lphi_n ...
            - 0.5*phi_n.^3 - 0.5*phi_n ...
            - beta*phi_n + (beta/2)*phi_nm1;
    Lknown = real(ifft2(Lambda .* fft2(known)));

    for iter = 1:max_iter
        Lquad = real(ifft2(Lambda .* fft2( (3/2)*phi_n.^2 .* phi_new )));
        rhs_phys = phi_n/tau + Lknown + Lquad;
        rhs_hat  = fft2(rhs_phys);
        c0_hat = 1/tau - Lambda .* ( -(eps_v^2/2)*Lambda - 0.5 + beta/2 );
        phi_new_hat  = rhs_hat ./ c0_hat;
        phi_new_iter = real(ifft2(phi_new_hat));

        if max(max(abs(phi_new_iter - phi_new))) < tol
            phi_new = phi_new_iter;
            break;
        end
        phi_new = phi_new_iter;
    end

    phi_nm1 = phi_n;
    phi_n   = phi_new;

    % ��ָ��ʱ�̼�¼����������
    for s = 2:length(T_save)
        if n == n_save(s)
            M_vals(s) = h^2 * sum(sum(phi_n));
            Lphi = real(ifft2(Lambda .* fft2(phi_n)));
            E_vals(s) = h^2 * sum(sum(0.25*(phi_n.^2 - 1).^2)) ...
                      + (eps_v^2/2) * h^2 * sum(sum((-Lphi) .* phi_n)) ...
                      + (beta/4) * h^2 * sum(sum((phi_n - phi_nm1).^2));
        end
    end

    if mod(n, 10000) == 0
        fprintf('  step %d / %d, elapsed = %.3f s\n', n, Nt, toc);
    end
end
fprintf('CPU time = %.3f s\n', toc);

%% ========== ������� ==========
M0 = M_vals(1);
E0 = E_vals(1);

fprintf('\n');
fprintf('--------------------------------------------------------------------------------------------\n');
fprintf('   T        M_h(phi^n)         Rel-err(M)       E_h(phi^n)         Rel-err(E)\n');
fprintf('--------------------------------------------------------------------------------------------\n');
for s = 1:length(T_save)
    relM = abs(M_vals(s) - M0) / abs(M0);
    relE = abs(E_vals(s) - E0) / abs(E0);
    fprintf('  %5.1f   %.18e   %.18e   %.18e   %.18e\n', ...
        T_save(s), M_vals(s), relM, E_vals(s), relE);
end
fprintf('--------------------------------------------------------------------------------------------\n');
fprintf('max |M(t)-M(0)| = %.14e\n', max(abs(M_vals - M0)));
fprintf('E(0) = %.18e, E(T) = %.18e\n', E0, E_vals(end));