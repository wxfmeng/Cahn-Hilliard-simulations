clc; clear; close all;
format long e

%% Parameters
eps_v = 0.05;
beta  = 2;
L     = 2*pi;
J     = 512;
h     = L/J;
x     = (0:J-1)'*h;
T     = 5;
tau   = 1e-3;
Nt    = round(T/tau);

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

%% Eigenvalues of L_h
k = (0:J-1)';
lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

A0 = -0.5 + beta/2;
c0_hat = 1/tau - lambda .* (A0 - (eps_v^2/2)*lambda);

%% Initial condition
rand('state', 20240101);
phi_n   = 0.5 + 0.1*(2*rand(J,1) - 1);
phi_nm1 = phi_n;

%% Save
t_save = 0:0.1:5;
n_save = round(t_save/tau);
phi_save = zeros(J, length(t_save));
phi_save(:,1) = phi_n;

%% Time stepping
max_iter = 20;
tol = 1e-12;
tic;

for n = 1:Nt
    if n == 1
        phi_new = phi_n;
    else
        phi_new = 2*phi_n - phi_nm1;
    end

    Lphi_n = real(ifft(lambda .* fft(phi_n)));
    known  = - (eps_v^2/2)*Lphi_n ...
             - 0.5*phi_n.^3 - 0.5*phi_n ...
             - beta*phi_n + (beta/2)*phi_nm1;
    Lknown = real(ifft(lambda .* fft(known)));

    for iter = 1:max_iter
        Lquad = real(ifft(lambda .* fft( (3/2)*phi_n.^2 .* phi_new )));
        rhs_phys = phi_n/tau + Lknown + Lquad;
        rhs_hat  = fft(rhs_phys);
        phi_new_hat  = rhs_hat ./ c0_hat;
        phi_new_iter = real(ifft(phi_new_hat));

        if max(abs(phi_new_iter - phi_new)) < tol
            phi_new = phi_new_iter;
            break;
        end
        phi_new = phi_new_iter;
    end

    phi_nm1 = phi_n;
    phi_n   = phi_new;

    for s = 2:length(t_save)
        if n == n_save(s)
            phi_save(:,s) = phi_n;
        end
    end

    if mod(n, 10000) == 0
        fprintf('  step %d / %d, elapsed = %.2f s\n', n, Nt, toc);
    end
end
fprintf('CPU time = %.2f s\n', toc);

%% Figure 2: four mesh subplots with different time ranges
T_range = [1, 1.5, 2, 3, 4, 5];   

for s = 1:6
    idx_sel = find(t_save <= T_range(s));
    t_plot  = t_save(idx_sel);
    phi_plot = phi_save(:, idx_sel);

    [Xg, Tg] = meshgrid(x, t_plot);
    Pg = transpose(phi_plot);

    figure(s);
    mesh(Xg, Tg, Pg);
    xlabel('x', 'FontSize', 11);
    ylabel('t', 'FontSize', 11);
    zlabel('\phi(x,t)', 'FontSize', 11);
    title(['T =' num2str(T_range(s)) ], 'FontSize', 11);
    set(gca, 'FontSize', 10);
    view(135, 30);        % �ָ���ͼ
    grid on;
end
