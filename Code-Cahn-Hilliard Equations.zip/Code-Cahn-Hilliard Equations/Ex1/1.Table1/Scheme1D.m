% CH1D_Spatial_Convergence.m
% 1D �ռ��������� (���ϸ��)
% h   = pi/4, pi/8, pi/16
% tau = 0.2/16, 0.2/16^2, 0.2/16^3
% T = 1
% ��������� Liu & Yin (2021)

clc; clear; close all;
format long e

%% ����
eps_v = 1;
beta  = 2;
L     = 2*pi;

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

%% ����
T = 1;
h_list   = [pi/4, pi/8, pi/16];
tau_list = [0.2/16, 0.2/16^2, 0.2/16^3];

errL2    = zeros(size(h_list));
errLinf  = zeros(size(h_list));
CPU_time = zeros(size(h_list));

%% ========== ��ѭ�� ==========
for idx = 1:length(h_list)
    h_nom = h_list(idx);
    J = round(L/h_nom);
    h = L/J;
    x = (0:J-1)'*h;

    % �˽׽�����������ֵ
    k = (0:J-1)';
    lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
    lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
    d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
    lambda = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

    % ��ֵ
    phi_n   = sin(x);
    phi_nm1 = phi_n;

    tau = tau_list(idx);
    Nt  = round(T/tau);
    tau = T/Nt;
    t   = 0;
    max_iter = 50;
    tol = 1e-14;

    tic;   % <<<<<< �޸ģ�MATLAB 7.0 ����

    for n = 1:Nt
        t_mid = t + 0.5*tau;
        s_mid = -exp(-t_mid).*sin(x) .* ( 3*exp(-2*t_mid).*cos(2*x) ...
                + 3*exp(-2*t_mid).*cos(x).^2 + 1 );

        if n == 1
            phi_new = phi_n;
        else
            phi_new = 2*phi_n - phi_nm1;
        end

        for iter = 1:max_iter
            term1 = phi_n / tau;
            known = - (eps_v^2/2)*real(ifft(lambda.*fft(phi_n))) ...
                    - 0.5*phi_n.^3 - 0.5*phi_n ...
                    - beta*phi_n + (beta/2)*phi_nm1;
            term2 = real(ifft(lambda .* fft(known)));
            term3 = real(ifft(lambda .* fft( (3/2)*phi_n.^2 .* phi_new )));
            rhs_phys = term1 + term2 + term3 + s_mid;
            rhs_hat  = fft(rhs_phys);

            c0_hat = 1/tau - lambda .* ( -(eps_v^2/2)*lambda - 0.5 + beta/2 );
            phi_new_hat  = rhs_hat ./ c0_hat;
            phi_new_iter = real(ifft(phi_new_hat));

            if max(abs(phi_new_iter - phi_new)) < tol
                phi_new = phi_new_iter;
                break;
            end
            phi_new = phi_new_iter;
        end

        phi_nm1 = phi_n;
        phi_n   = phi_new;
        t = t + tau;
    end

    CPU_time(idx) = toc;   % <<<<<< �޸ģ�MATLAB 7.0 ����

    % ���
    phi_exact = exp(-T) * sin(x);
    errL2(idx)   = sqrt(h*sum(abs(phi_n - phi_exact).^2));
    errLinf(idx) = max(abs(phi_n - phi_exact));
end

%% ========== ������� ==========
fprintf('\n');
fprintf('----------------------------------------------------------------------------------------\n');
fprintf('  h        tau          ||e^n||        Rate      ||e^n||_inf     Rate      CPU(s)\n');
fprintf('----------------------------------------------------------------------------------------\n');

for kk = 1:length(h_list)
    if kk == 1
        fprintf('  pi/%-3d   %.4e   %.6e     --        %.6e     --        %.2f\n', ...
            round(pi/h_list(kk)), tau_list(kk), errL2(kk), errLinf(kk), CPU_time(kk));
    else
        rL2 = log2(errL2(kk-1)/errL2(kk));
        rLi = log2(errLinf(kk-1)/errLinf(kk));
        fprintf('  pi/%-3d   %.4e   %.6e     %.2f      %.6e     %.2f      %.2f\n', ...
            round(pi/h_list(kk)), tau_list(kk), errL2(kk), rL2, errLinf(kk), rLi, CPU_time(kk));
    end
end
fprintf('----------------------------------------------------------------------------------------\n');