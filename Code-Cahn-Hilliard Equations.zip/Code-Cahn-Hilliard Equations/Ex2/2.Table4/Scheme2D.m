% CH2D_Temporal_Convergence.m
% 2D ʱ����������
% ��ȷ��: phi(x,y,t)=0.1*exp(-t/4)*sin(x)*sin(y)
% ����: [0,2*pi]^2, ���ڱ߽�
% eps = 0.1, beta = 2, T = 1
% h   = pi/20      (J = 40)
% tau = 0.2, 0.1, 0.05, 0.025
% ���������� Liu & Yin (2021)

clc; clear; close all;
format long e

%% ����
eps_v = 0.1;
beta  = 2;
L     = 2*pi;

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

%% ����
T        = 0.1;
h_fixed  = pi/20;
tau_list = [0.025, 0.0125, 0.00625, 0.003125];

J = round(L/h_fixed);
h = L/J;
x = (0:J-1)'*h;
y = (0:J-1)'*h;
[X, Y] = meshgrid(x, y);

% һά�˽׽�����������ֵ
k = (0:J-1)';
lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda_1d = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

% ��ά����ֵ (������)
lambda_x = lambda_1d';
Lambda = repmat(lambda_x, J, 1) + repmat(lambda_1d, 1, J);

% ������˹���ӷ��� (����Դ��)
kx = [0:J/2-1, -J/2:-1] * (2*pi/L);
ky = kx;
[KX, KY] = meshgrid(kx, ky);
lap_spec = -(KX.^2 + KY.^2);

errL2    = zeros(size(tau_list));
errLinf  = zeros(size(tau_list));
CPU_time = zeros(size(tau_list));

%% ========== ��ѭ�� ==========
for idx_tau = 1:length(tau_list)
    tau = tau_list(idx_tau);
    Nt  = round(T/tau);
    tau = T/Nt;
    t   = 0;
    max_iter = 50;
    tol = 1e-14;

    % ��ֵ
    phi_n   = 0.1 * sin(X) .* sin(Y);
    phi_nm1 = phi_n;

    tic;

    for n = 1:Nt
        t_mid = t + 0.5*tau;

        % Դ�� (������Զ�����)
        phi_mid   = 0.1 * exp(-t_mid/4) * sin(X) .* sin(Y);
        phi_t_mid = -0.25 * phi_mid;
        Lap_phi   = real(ifft2(lap_spec .* fft2(phi_mid)));
        mu_mid    = phi_mid.^3 - phi_mid - eps_v^2 * Lap_phi;
        Lap_mu    = real(ifft2(lap_spec .* fft2(mu_mid)));
        s_mid     = phi_t_mid - Lap_mu;

        if n == 1
            phi_new = phi_n;
        else
            phi_new = 2*phi_n - phi_nm1;
        end

        for iter = 1:max_iter
            term1 = phi_n / tau;
            known = - (eps_v^2/2)*real(ifft2(Lambda .* fft2(phi_n))) ...
                    - 0.5*phi_n.^3 - 0.5*phi_n ...
                    - beta*phi_n + (beta/2)*phi_nm1;
            term2 = real(ifft2(Lambda .* fft2(known)));
            term3 = real(ifft2(Lambda .* fft2( (3/2)*phi_n.^2 .* phi_new )));
            rhs_phys = term1 + term2 + term3 + s_mid;
            rhs_hat  = fft2(rhs_phys);

            c0_hat = 1/tau - Lambda .* ( -(eps_v^2/2)*Lambda - 0.5 + beta/2 );
            phi_new_hat  = rhs_hat ./ c0_hat;
            phi_new_iter = real(ifft2(phi_new_hat));

            if max(max(abs(phi_new_iter - phi_new))) < tol
                phi_new = phi_new_iter;
                break;
            end
            phi_new = phi_new_iter;
        end

        phi_nm1 = phi_n;
        phi_n   = phi_new;
        t = t + tau;
    end

    CPU_time(idx_tau) = toc;

    % ���
    phi_exact = 0.1 * exp(-T/4) * sin(X) .* sin(Y);
    errL2(idx_tau)   = sqrt(h^2 * sum(sum((phi_n - phi_exact).^2)));
    errLinf(idx_tau) = max(max(abs(phi_n - phi_exact)));

    fprintf('  tau=%10.4e  CPU=%.2fs  done\n', tau, CPU_time(idx_tau));
end

%% ========== ������� ==========
fprintf('\n');
fprintf('---------------------------------------------------------------------------------------\n');
fprintf('  tau          ||e^n||        Rate      ||e^n||_inf     Rate      CPU(s)\n');
fprintf('---------------------------------------------------------------------------------------\n');

for kk = 1:length(tau_list)
    if kk == 1
        fprintf('  %.4e   %.6e     --        %.6e     --        %.2f\n', ...
            tau_list(kk), errL2(kk), errLinf(kk), CPU_time(kk));
    else
        rL2 = log2(errL2(kk-1)/errL2(kk));
        rLi = log2(errLinf(kk-1)/errLinf(kk));
        fprintf('  %.4e   %.6e     %.2f      %.6e     %.2f      %.2f\n', ...
            tau_list(kk), errL2(kk), rL2, errLinf(kk), rLi, CPU_time(kk));
    end
end
fprintf('---------------------------------------------------------------------------------------\n');