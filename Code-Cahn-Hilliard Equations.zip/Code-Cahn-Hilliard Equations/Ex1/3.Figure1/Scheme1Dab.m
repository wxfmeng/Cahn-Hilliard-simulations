% Figure3_1D_NumVsExact_final2.m
% h = pi/16,  tau = 0.2/16
% h = pi/32, tau = 0.2/16^2
% ��ȷ��: phi(x,t) = exp(-t)*sin(x)



clc; clear; close all;
format long e

eps_v = 1;  beta = 2;  L = 2*pi;  T = 1;
a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

%% ===== ͼ 1: h = pi/16, tau = 0.2/16 =====
h = pi/16;  J = round(L/h);  h = L/J;
x = (0:J-1)'*h;
k = (0:J-1)';
lambda_Sx  = -4/h^2*sin(pi*k/J).^2;
lambda_S2x = -4/h^2*sin(pi*k/J).^2.*cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda = (a3*lambda_S2x + a4*lambda_Sx)./d_hat;
phi_n = sin(x);  phi_nm1 = phi_n;
tau = 0.2/16;  Nt = round(T/tau);  tau = T/Nt;
t = 0;  max_iter = 50;  tol = 1e-14;
for n = 1:Nt
    t_mid = t + 0.5*tau;
    s_mid = -exp(-t_mid).*sin(x).*(3*exp(-2*t_mid).*cos(2*x) ...
            + 3*exp(-2*t_mid).*cos(x).^2 + 1);
    if n == 1, phi_new = phi_n; else, phi_new = 2*phi_n - phi_nm1; end
    for iter = 1:max_iter
        term1 = phi_n/tau;
        known = -(eps_v^2/2)*real(ifft(lambda.*fft(phi_n))) ...
                - 0.5*phi_n.^3 - 0.5*phi_n - beta*phi_n + (beta/2)*phi_nm1;
        term2 = real(ifft(lambda.*fft(known)));
        term3 = real(ifft(lambda.*fft((3/2)*phi_n.^2.*phi_new)));
        rhs_phys = term1 + term2 + term3 + s_mid;
        rhs_hat = fft(rhs_phys);
        c0_hat = 1/tau - lambda.*(-(eps_v^2/2)*lambda - 0.5 + beta/2);
        phi_new_iter = real(ifft(rhs_hat./c0_hat));
        if max(abs(phi_new_iter - phi_new)) < tol
            phi_new = phi_new_iter;  break;
        end
        phi_new = phi_new_iter;
    end
    phi_nm1 = phi_n;  phi_n = phi_new;  t = t + tau;
end
phi_exact = exp(-T)*sin(x);

figure(1); clf;
set(gcf, 'Color', 'w');
plot([x; 2*pi], [phi_exact; phi_exact(1)], 'k-',  'LineWidth', 2); hold on;
plot([x; 2*pi], [phi_n;     phi_n(1)],     'bo--','LineWidth', 2, ...
     'MarkerSize', 6);
hold off;
xlabel('x', 'FontSize', 12);
ylabel('\phi', 'FontSize', 12);
title('h=\pi/16,\tau=0.2/16, T=1', 'FontSize', 12);
legend('Exact', 'Numerical', 'Location', 'Best');
set(gca, 'FontSize', 11);
axis([0, 2*pi, -0.4, 0.4]);
grid on;

%% ===== ͼ 2: h = pi/32, tau = 0.2/16^2 =====
h = pi/32;  J = round(L/h);  h = L/J;
x = (0:J-1)'*h;
k = (0:J-1)';
lambda_Sx  = -4/h^2*sin(pi*k/J).^2;
lambda_S2x = -4/h^2*sin(pi*k/J).^2.*cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda = (a3*lambda_S2x + a4*lambda_Sx)./d_hat;
phi_n = sin(x);  phi_nm1 = phi_n;
tau = 0.2/16^2;  Nt = round(T/tau);  tau = T/Nt;
t = 0;  max_iter = 50;  tol = 1e-14;
for n = 1:Nt
    t_mid = t + 0.5*tau;
    s_mid = -exp(-t_mid).*sin(x).*(3*exp(-2*t_mid).*cos(2*x) ...
            + 3*exp(-2*t_mid).*cos(x).^2 + 1);
    if n == 1, phi_new = phi_n; else, phi_new = 2*phi_n - phi_nm1; end
    for iter = 1:max_iter
        term1 = phi_n/tau;
        known = -(eps_v^2/2)*real(ifft(lambda.*fft(phi_n))) ...
                - 0.5*phi_n.^3 - 0.5*phi_n - beta*phi_n + (beta/2)*phi_nm1;
        term2 = real(ifft(lambda.*fft(known)));
        term3 = real(ifft(lambda.*fft((3/2)*phi_n.^2.*phi_new)));
        rhs_phys = term1 + term2 + term3 + s_mid;
        rhs_hat = fft(rhs_phys);
        c0_hat = 1/tau - lambda.*(-(eps_v^2/2)*lambda - 0.5 + beta/2);
        phi_new_iter = real(ifft(rhs_hat./c0_hat));
        if max(abs(phi_new_iter - phi_new)) < tol
            phi_new = phi_new_iter;  break;
        end
        phi_new = phi_new_iter;
    end
    phi_nm1 = phi_n;  phi_n = phi_new;  t = t + tau;
end
phi_exact = exp(-T)*sin(x);

figure(2); clf;
set(gcf, 'Color', 'w');
plot([x; 2*pi], [phi_exact; phi_exact(1)], 'k-',  'LineWidth', 2); hold on;
plot([x; 2*pi], [phi_n;     phi_n(1)],     'ro--','LineWidth', 2, ...
     'MarkerSize', 6);
hold off;
xlabel('x', 'FontSize', 12);
ylabel('\phi', 'FontSize', 12);
title('h=\pi/32,\tau=0.2/16^2, T=1', 'FontSize', 12);
legend('Exact', 'Numerical', 'Location', 'Best');
set(gca, 'FontSize', 11);
axis([0, 2*pi, -0.4, 0.4]);
grid on;