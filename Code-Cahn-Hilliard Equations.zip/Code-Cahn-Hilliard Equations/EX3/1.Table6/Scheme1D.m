% CH1D_Degenerate_Compare.m
% 1D comparison: 2nd LSS vs 8th compact for degenerate-mobility CH
% M(phi) = phi^2, following Lee & Lee 2025

clc; clear; close all;
format long e

eps_v   = 1e-7;
delta_t = 2^-35;
Nt      = 100;

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

% All meshes needed: 1/8 to 1/1024
J_list = [8, 16, 32, 64, 128, 256, 512, 1024];

phi_sol = cell(length(J_list), 1);

for idx = 1:length(J_list)
    J = J_list(idx);
    h = 1/J;
    x = (0:J-1)'*h;

    k = (0:J-1)';
    lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
    lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
    d_hat      = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
    lambda     = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

    ik = 1i * [0:J/2-1, -J/2:-1]';

    phi = cos(2*pi*x);

    for n = 1:Nt
        L_phi = real(ifft(lambda .* fft(phi)));
        mu = phi.^3 - phi - eps_v^2 * L_phi;

        phi_x = real(ifft(ik .* fft(phi)));
        mu_x  = real(ifft(ik .* fft(mu)));

        M   = phi.^2;
        M_x = 2 * phi .* phi_x;

        mu_xx = real(ifft(lambda .* fft(mu)));

        rhs = M .* mu_xx + M_x .* mu_x;

        phi = phi + delta_t * rhs;
    end

    phi_sol{idx} = phi;
end

%% Same-mesh comparison: h = 1/64, 1/128, 1/256, 1/512
% Reference for h is the solution on h/2
fprintf('\n');
fprintf('===== Same-mesh comparison =====\n');
fprintf('  h        ||e||_2 (8th compact)    ||e||_inf (8th compact)\n');
fprintf('---------------------------------------------------------------\n');

J_target = [64, 128, 256, 512];
for idx = 1:length(J_target)
    Jc = J_target(idx);
    Jf = 2*Jc;

    ic = find(J_list == Jc);
    iff = find(J_list == Jf);

    phi_c = phi_sol{ic};
    phi_f = phi_sol{iff};
    phi_fc = phi_f(1:2:end);

    e = phi_fc - phi_c;
    hc = 1/Jc;
    eL2   = sqrt(hc * sum(e.^2));
    eLinf = max(abs(e));

    fprintf('  1/%-4d   %.6e                %.6e\n', Jc, eL2, eLinf);
end
fprintf('---------------------------------------------------------------\n');

%% Cross-mesh comparison: 8th compact on coarse meshes
fprintf('\n');
fprintf('===== 8th compact on coarse meshes (same physical settings) =====\n');
fprintf('  h        ||e||_2 (8th compact)    ||e||_inf (8th compact)\n');
fprintf('---------------------------------------------------------------\n');

J_coarse = [8, 16, 32, 64];
for idx = 1:length(J_coarse)
    Jc = J_coarse(idx);
    Jf = 2*Jc;

    ic = find(J_list == Jc);
    iff = find(J_list == Jf);

    phi_c = phi_sol{ic};
    phi_f = phi_sol{iff};
    phi_fc = phi_f(1:2:end);

    e = phi_fc - phi_c;
    hc = 1/Jc;
    eL2   = sqrt(hc * sum(e.^2));
    eLinf = max(abs(e));

    fprintf('  1/%-4d   %.6e                %.6e\n', Jc, eL2, eLinf);
end
fprintf('---------------------------------------------------------------\n');