% CH2D_Mass_Energy.m
% ��� 2D CH ���̵�����������ɢ����
% ����: [0,1]^2, ���ڱ߽�
% eps = 0.05, beta = 2, h = 0.01, tau = 1e-3, T = 100
% ��ֵ: phi(x,y,0) = 0.5 + ����Ŷ�

clc; clear; close all;
format long e

%% ����
eps_v = 0.05;
beta  = 2;
L     = 1;
h     = 0.01;
tau   = 1e-3;
T     = 100; % �ӳ�ģ��ʱ�䣬ʹ�ֻ������������

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

J = round(L/h);
h = L/J;
x = (0:J-1)'*h;
y = (0:J-1)'*h;
[X, Y] = meshgrid(x, y);

% �˽׽�����������ֵ
k = (0:J-1)';
lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda_1d = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

% ��ά����ֵ (������)
lambda_x = lambda_1d';
Lambda = repmat(lambda_x, J, 1) + repmat(lambda_1d, 1, J);

% --- �޸ĳ�ֵ����������Ŷ��Դ��ƶԳ��ԣ���������� ---
randn('state', 12345); % �̶�����������Ա�֤���ظ���
% �����ʼ����
phi_n   = 0.5 + 0.02 * randn(J, J);
phi_nm1 = phi_n;

% ��¼ʱ�̣�������������
T_save = [0, 10, 20, 40, 60, 80, 100];
n_save = round(T_save/tau);
n_save(1) = 0;

% ��Ҫ��ͼ��ʱ��
T_plot = [1, 5, 10, 20, 50, 100];
n_plot = round(T_plot/tau);

% �洢����������
M_vals = zeros(size(T_save));
E_vals = zeros(size(T_save));

% �洢�ĸ�ʱ�̵���ֵ��
phi_plot = zeros(J, J, length(T_plot));

% �����ʼʱ�̵�����������
M_vals(1) = h^2 * sum(sum(phi_n));
Lphi_0 = real(ifft2(Lambda .* fft2(phi_n)));
E_vals(1) = h^2 * sum(sum(0.25*(phi_n.^2 - 1).^2)) ...
          + (eps_v^2/2) * h^2 * sum(sum((-Lphi_0) .* phi_n));

%% ʱ���ƽ�
Nt = round(T/tau);
max_iter = 20;
tol = 1e-12;

time_hist = (1:Nt) * tau;
L_vals = zeros(1, Nt);
E_hist = zeros(1, Nt); 

[kx, ky] = meshgrid(2*pi/L * [0:J/2-1, -J/2:-1], 2*pi/L * [0:J/2-1, -J/2:-1]);
k_mag = sqrt(kx.^2 + ky.^2);
k_mag(1,1) = 1e6; % �ų� k=0 ����ģ

tic;
for n = 1:Nt
    if n == 1
        phi_new = phi_n;
    else
        phi_new = 2*phi_n - phi_nm1;
    end

    Lphi_n = real(ifft2(Lambda .* fft2(phi_n)));
    known = - (eps_v^2/2)*Lphi_n ...
            - 0.5*phi_n.^3 - 0.5*phi_n ...
            - beta*phi_n + (beta/2)*phi_nm1;
    Lknown = real(ifft2(Lambda .* fft2(known)));

    for iter = 1:max_iter
        Lquad = real(ifft2(Lambda .* fft2( (3/2)*phi_n.^2 .* phi_new )));
        rhs_phys = phi_n/tau + Lknown + Lquad;
        rhs_hat  = fft2(rhs_phys);
        c0_hat = 1/tau - Lambda .* ( -(eps_v^2/2)*Lambda - 0.5 + beta/2 );
        phi_new_hat  = rhs_hat ./ c0_hat;
        phi_new_iter = real(ifft2(phi_new_hat));

        if max(max(abs(phi_new_iter - phi_new))) < tol
            phi_new = phi_new_iter;
            break;
        end
        phi_new = phi_new_iter;
    end

    phi_nm1 = phi_n;
    phi_n   = phi_new;

    % ���������������ߴ�
    Lphi = real(ifft2(Lambda .* fft2(phi_n))); 
    Interface_Area = h^2 * sum(sum((-Lphi) .* phi_n)); 
    
    E_hist(n) = h^2 * sum(sum(0.25*(phi_n.^2 - 1).^2)) ...
              + (eps_v^2/2) * Interface_Area ...
              + (beta/4) * h^2 * sum(sum((phi_n - phi_nm1).^2));
          
    phi_hat = fft2(phi_n);
    S_k = abs(phi_hat).^2; 
    S_k(1,1) = 0; 
    L_vals(n) = 2*pi * sum(S_k(:)) / sum(k_mag(:) .* S_k(:)); 

    % ��¼�ض�ʱ��
    for s = 2:length(T_save)
        if n == n_save(s)
            M_vals(s) = h^2 * sum(sum(phi_n));
            E_vals(s) = E_hist(n); 
        end
    end

    % ����ͼƬ����
    for s = 1:length(T_plot)
        if n == n_plot(s)
            phi_plot(:,:,s) = phi_n;
        end
    end

    if mod(n, 10000) == 0
        fprintf('  step %d / %d, elapsed = %.3f s\n', n, Nt, toc);
    end
end
fprintf('CPU time = %.3f s\n', toc);

%% ========== ������� ==========
M0 = M_vals(1);
E0 = E_vals(1);

fprintf('\n');
fprintf('--------------------------------------------------------------------------------------------\n');
fprintf('   T        M_h(phi^n)         Rel-err(M)       E_h(phi^n)         Rel-err(E)\n');
fprintf('--------------------------------------------------------------------------------------------\n');
for s = 1:length(T_save)
    relM = abs(M_vals(s) - M0) / abs(M0);
    relE = abs(E_vals(s) - E0) / abs(E0);
    fprintf('  %5.1f   %.18e   %.18e   %.18e   %.18e\n', ...
        T_save(s), M_vals(s), relM, E_vals(s), relE);
end
fprintf('--------------------------------------------------------------------------------------------\n');

%% ========== ͼ 7: Coarsening �����ߴ��ݻ� (Linear) ==========
figure(7); clf;
set(gcf, 'Color', 'w', 'Position', [100 100 600 450]); 

start_idx = round(0.5 / tau); 

plot(time_hist(start_idx:end), L_vals(start_idx:end), 'b-', 'LineWidth', 2); hold on;

xlabel('Time t', 'FontSize', 10);
ylabel('Characteristic length L(t)', 'FontSize', 10);
title('Evolution of Characteristic Domain Size', 'FontSize', 12);
grid on;
set(gca, 'FontSize', 10);
xlim([0, 20]); 

%% ========== ͼ 8: �����ܳ�ʱ���ݻ� (Semi-Log) ==========
figure(8); clf;
set(gcf, 'Color', 'w', 'Position', [200 200 600 450]); 

semilogy(time_hist, E_hist, 'k-', 'LineWidth', 2); hold on;

xlabel('Time t', 'FontSize', 10);
ylabel('Discrete Energy E_h', 'FontSize', 10);
title('Energy Dissipation over Long-time Simulation', 'FontSize', 12);
grid on;
set(gca, 'FontSize', 10);
xlim([0, 100]);