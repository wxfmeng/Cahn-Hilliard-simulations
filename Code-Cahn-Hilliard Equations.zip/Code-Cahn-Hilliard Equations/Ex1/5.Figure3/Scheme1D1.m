% Figure2_1D_WaveEvolution_plot_early.m
% Figure 2: phi(x,t) at t = 0, 1, 2, 5, 10 in one plot
% 1D CH equation, Omega = [0, 2*pi], periodic BC
% eps = 0.05, J = 512, tau = 1e-3, T = 50, beta = 2
% phi(x,0) = 0.5 + 0.1*rand(x), rand ~ U[-1,1]

clc; clear; close all;
format long e

%% Parameters
eps_v = 0.05;
beta  = 2;
L     = 2*pi;
J     = 512;
h     = L/J;
x     = (0:J-1)'*h;
T     = 50;
tau   = 1e-3;
Nt    = round(T/tau);

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

%% Eigenvalues of L_h
k = (0:J-1)';
lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

A0 = -0.5 + beta/2;
c0_hat = 1/tau - lambda .* (A0 - (eps_v^2/2)*lambda);

%% Initial condition
rand('state', 20240101);
phi_n   = 0.5 + 0.1*(2*rand(J,1) - 1);
phi_nm1 = phi_n;

%% Snapshots at early times: t = 0, 1, 2, 5, 10
t_sel  = [0, 1, 2, 5, 10];
n_sel  = round(t_sel/tau);
phi_sel = zeros(J, length(t_sel));
phi_sel(:,1) = phi_n;

%% Time stepping
max_iter = 20;
tol = 1e-12;
tic;

for n = 1:Nt
    if n == 1
        phi_new = phi_n;
    else
        phi_new = 2*phi_n - phi_nm1;
    end

    Lphi_n = real(ifft(lambda .* fft(phi_n)));
    known  = - (eps_v^2/2)*Lphi_n ...
             - 0.5*phi_n.^3 - 0.5*phi_n ...
             - beta*phi_n + (beta/2)*phi_nm1;
    Lknown = real(ifft(lambda .* fft(known)));

    for iter = 1:max_iter
        Lquad = real(ifft(lambda .* fft( (3/2)*phi_n.^2 .* phi_new )));
        rhs_phys = phi_n/tau + Lknown + Lquad;
        rhs_hat  = fft(rhs_phys);
        phi_new_hat  = rhs_hat ./ c0_hat;
        phi_new_iter = real(ifft(phi_new_hat));

        if max(abs(phi_new_iter - phi_new)) < tol
            phi_new = phi_new_iter;
            break;
        end
        phi_new = phi_new_iter;
    end

    phi_nm1 = phi_n;
    phi_n   = phi_new;

    for s = 2:length(t_sel)
        if n == n_sel(s)
            phi_sel(:,s) = phi_n;
        end
    end
end
fprintf('CPU time = %.2f s\n', toc);

%% Plot: 5 curves in one figure
figure(1); clf;
set(gcf, 'Color', 'w');
hold on;
plot(x, phi_sel(:,5), 'r-',  'LineWidth', 1.3);   % t = 10
plot(x, phi_sel(:,4), 'm--', 'LineWidth', 1.3);   % t = 5
plot(x, phi_sel(:,3), 'g-.', 'LineWidth', 1.3);   % t = 2
plot(x, phi_sel(:,2), 'b:',  'LineWidth', 1.5);   % t = 1
plot(x, phi_sel(:,1), 'k-',  'LineWidth', 1.3);   % t = 0
hold off;

xlabel('x', 'FontSize', 12);
ylabel('\phi(x,t)', 'FontSize', 12);
title('1D Cahn-Hilliard: \phi(x,t) at t = 0, 1, 2, 5, 10', 'FontSize', 12);
legend('t = 10', 't = 5', 't = 2', 't = 1', 't = 0', ...
       'Location', 'Best');
set(gca, 'FontSize', 11);
xlim([0, 2*pi]);
ylim([0, 1]);
grid on;

print('-depsc', 'Fig2_1D_Curves_Early.eps');