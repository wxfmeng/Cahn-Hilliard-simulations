% CH2D_Spatial_Convergence_ErrorPlot.m
% ���� 2D ����⣬���� T=0.5 �� T=1 ʱ����ֵ�⼰���
% ��ȷ��: phi(x,y,t)=0.1*exp(-t/4)*sin(x)*sin(y)
% ����: [0,2*pi]^2, ���ڱ߽�
% eps = 0.1, beta = 2
% h = pi/8, tau = 0.2/16^2
% ���������� Liu & Yin (2021)

clc; clear; close all;
format long e

%% ����
eps_v = 0.5;
beta  = 2;
L     = 2*pi;

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

%% ����
T = 1;
h = pi/32;
tau = 0.2/16^2;

J = round(L/h);
h = L/J;
x = (0:J-1)'*h;
y = (0:J-1)'*h;
[X, Y] = meshgrid(x, y);

% һά�˽׽�����������ֵ
k = (0:J-1)';
lambda_Sx  = -4/h^2 * sin(pi*k/J).^2;
lambda_S2x = -4/h^2 * sin(pi*k/J).^2 .* cos(pi*k/J).^2;
d_hat = 1 + 2*b2*cos(2*pi*k/J) + 2*b1*cos(4*pi*k/J);
lambda_1d = (a3*lambda_S2x + a4*lambda_Sx) ./ d_hat;

% ��ά����ֵ (������)
lambda_x = lambda_1d';
Lambda = repmat(lambda_x, J, 1) + repmat(lambda_1d, 1, J);

% ������˹���ӷ��� (����Դ��)
kx = [0:J/2-1, -J/2:-1] * (2*pi/L);
ky = kx;
[KX, KY] = meshgrid(kx, ky);
lap_spec = -(KX.^2 + KY.^2);

% ��ֵ
phi_n   = 0.1 * sin(X) .* sin(Y);
phi_nm1 = phi_n;

% ����ʱ��
T_save = [0.5, 1];
n_save = round(T_save/tau);

phi_save_05 = [];
phi_save_10 = [];

%% ʱ���ƽ�
Nt = round(T/tau);
t  = 0;
max_iter = 50;
tol = 1e-14;

tic;
for n = 1:Nt
    t_mid = t + 0.5*tau;
    phi_mid   = 0.1 * exp(-t_mid/4) * sin(X) .* sin(Y);
    phi_t_mid = -0.25 * phi_mid;
    Lap_phi   = real(ifft2(lap_spec .* fft2(phi_mid)));
    mu_mid    = phi_mid.^3 - phi_mid - eps_v^2 * Lap_phi;
    Lap_mu    = real(ifft2(lap_spec .* fft2(mu_mid)));
    s_mid     = phi_t_mid - Lap_mu;

    if n == 1
        phi_new = phi_n;
    else
        phi_new = 2*phi_n - phi_nm1;
    end

    for iter = 1:max_iter
        term1 = phi_n / tau;
        known = - (eps_v^2/2)*real(ifft2(Lambda .* fft2(phi_n))) ...
                - 0.5*phi_n.^3 - 0.5*phi_n ...
                - beta*phi_n + (beta/2)*phi_nm1;
        term2 = real(ifft2(Lambda .* fft2(known)));
        term3 = real(ifft2(Lambda .* fft2( (3/2)*phi_n.^2 .* phi_new )));
        rhs_phys = term1 + term2 + term3 + s_mid;
        rhs_hat  = fft2(rhs_phys);

        c0_hat = 1/tau - Lambda .* ( -(eps_v^2/2)*Lambda - 0.5 + beta/2 );
        phi_new_hat  = rhs_hat ./ c0_hat;
        phi_new_iter = real(ifft2(phi_new_hat));

        if max(max(abs(phi_new_iter - phi_new))) < tol
            phi_new = phi_new_iter;
            break;
        end
        phi_new = phi_new_iter;
    end

    phi_nm1 = phi_n;
    phi_n   = phi_new;
    t = t + tau;

    if n == n_save(1), phi_save_05 = phi_n; end
    if n == n_save(2), phi_save_10 = phi_n; end
end
fprintf('CPU time = %.3f s\n', toc);

%% ��ȷ�������
phi_exact_05 = 0.1 * exp(-0.5/4) * sin(X) .* sin(Y);
phi_exact_10 = 0.1 * exp(-1.0/4) * sin(X) .* sin(Y);

err_05 = phi_save_05 - phi_exact_05;
err_10 = phi_save_10 - phi_exact_10;

fprintf('T=0.5: ||e||_2 = %.4e, ||e||_inf = %.4e\n', ...
    sqrt(h^2*sum(sum(err_05.^2))), max(max(abs(err_05))));
fprintf('T=1.0: ||e||_2 = %.4e, ||e||_inf = %.4e\n', ...
    sqrt(h^2*sum(sum(err_10.^2))), max(max(abs(err_10))));

%% ===== ��ͼ =====
% ͼ1: T=0.5 ��ֵ��
figure(1); clf;
set(gcf, 'Color', 'w');
mesh(X, Y, phi_save_05);
xlabel('x'); ylabel('y'); zlabel('\phi');
title('Numerical solution at T = 0.5');
view(135, 30); colorbar;


% ͼ2: T=1 ��ֵ��
figure(2); clf;
set(gcf, 'Color', 'w');
mesh(X, Y, phi_save_10);
xlabel('x'); ylabel('y'); zlabel('\phi');
title('Numerical solution at T = 1');
view(135, 30); colorbar;


% ͼ3: T=0.5 ���
figure(3); clf;
set(gcf, 'Color', 'w');
mesh(X, Y, err_05);
xlabel('x'); ylabel('y'); zlabel('e');
title('Error at T = 0.5');
%view(45, 20); 
colorbar;


% ͼ4: T=1 ���
figure(4); clf;
set(gcf, 'Color', 'w');
mesh(X, Y, err_10);
xlabel('x'); ylabel('y'); zlabel('e');
title('Error at T = 1');
%view(45, 20); 
colorbar;
