% CH2D_EighthOrder_v3.m
% 2D CH: 8th-order compact space + Lee et al. (2014) first-order time
% Parameters identical to Lee et al. (2014) Table 1

clc; clear; close all;
format long e

% ===== Parameters (identical to Lee et al. 2014) =====
eps_v = 0.0075;
dt    = 6e-4;
T     = 24*dt;
Nt    = round(T/dt);

a3 = 310/393;  a4 = 320/393;
b1 = 23/2358;  b2 = 344/1179;

J_list = [8, 16, 32, 64];
J_ref  = 256;

% ===== Reference solution on J_ref x J_ref =====
J = J_ref;
h = 1/J;
kx = (0:J-1)';
ky = (0:J-1)';
lam_Sx_x  = -4/h^2 * sin(pi*kx/J).^2;
lam_S2x_x = -4/h^2 * sin(pi*kx/J).^2 .* cos(pi*kx/J).^2;
d_x = 1 + 2*b2*cos(2*pi*kx/J) + 2*b1*cos(4*pi*kx/J);
lambda_x = (a3*lam_S2x_x + a4*lam_Sx_x) ./ d_x;

lam_Sx_y  = -4/h^2 * sin(pi*ky/J).^2;
lam_S2x_y = -4/h^2 * sin(pi*ky/J).^2 .* cos(pi*ky/J).^2;
d_y = 1 + 2*b2*cos(2*pi*ky/J) + 2*b1*cos(4*pi*ky/J);
lambda_y = (a3*lam_S2x_y + a4*lam_Sx_y) ./ d_y;

[Lx, Ly] = meshgrid(lambda_x, lambda_y);
lambda_2D = Lx + Ly;
denom_ref = 1/dt - 2*lambda_2D + eps_v^2*lambda_2D.^2;

[X, Y] = meshgrid((0:J-1)*h, (0:J-1)*h);
phi = 0.1*cos(2*pi*X).*cos(2*pi*Y);

fprintf('Computing reference solution on %dx%d...\n', J, J);
for n = 1:Nt
    rhs_hat = fft2(phi)/dt + lambda_2D .* fft2(phi.^3 - 3*phi);
    phi = real(ifft2(rhs_hat ./ denom_ref));
end
phi_ref = phi;

% ===== Coarse grid solutions =====
err_L2   = zeros(length(J_list),1);
err_Linf = zeros(length(J_list),1);
order_L2   = zeros(length(J_list)-1,1);
order_Linf = zeros(length(J_list)-1,1);

for idx = 1:length(J_list)
    J = J_list(idx);
    h = 1/J;
    
    kx = (0:J-1)';
    ky = (0:J-1)';
    lam_Sx_x  = -4/h^2 * sin(pi*kx/J).^2;
    lam_S2x_x = -4/h^2 * sin(pi*kx/J).^2 .* cos(pi*kx/J).^2;
    d_x = 1 + 2*b2*cos(2*pi*kx/J) + 2*b1*cos(4*pi*kx/J);
    lambda_x = (a3*lam_S2x_x + a4*lam_Sx_x) ./ d_x;
    
    lam_Sx_y  = -4/h^2 * sin(pi*ky/J).^2;
    lam_S2x_y = -4/h^2 * sin(pi*ky/J).^2 .* cos(pi*ky/J).^2;
    d_y = 1 + 2*b2*cos(2*pi*ky/J) + 2*b1*cos(4*pi*ky/J);
    lambda_y = (a3*lam_S2x_y + a4*lam_Sx_y) ./ d_y;
    
    [Lx, Ly] = meshgrid(lambda_x, lambda_y);
    lambda_2D = Lx + Ly;
    denom = 1/dt - 2*lambda_2D + eps_v^2*lambda_2D.^2;
    
    [X, Y] = meshgrid((0:J-1)*h, (0:J-1)*h);
    phi = 0.1*cos(2*pi*X).*cos(2*pi*Y);
    
    fprintf('Computing solution on %dx%d...\n', J, J);
    for n = 1:Nt
        rhs_hat = fft2(phi)/dt + lambda_2D .* fft2(phi.^3 - 3*phi);
        phi = real(ifft2(rhs_hat ./ denom));
    end
    
    step = J_ref / J;
    phi_ref_c = phi_ref(1:step:end, 1:step:end);
    e = phi - phi_ref_c;
    err_L2(idx)   = sqrt(h^2 * sum(sum(e.^2)));
    err_Linf(idx) = max(max(abs(e)));
end

for idx = 1:length(J_list)-1
    order_L2(idx)   = log2(err_L2(idx)   / err_L2(idx+1));
    order_Linf(idx) = log2(err_Linf(idx) / err_Linf(idx+1));
end

fprintf('\n');
fprintf('------------------------------------------------------------------------\n');
fprintf('  h        ||e||_2         Rate      ||e||_inf       Rate\n');
fprintf('------------------------------------------------------------------------\n');
for idx = 1:length(J_list)
    if idx == 1
        fprintf('  1/%-4d   %.6e     --        %.6e     --\n', ...
            J_list(idx), err_L2(idx), err_Linf(idx));
    else
        fprintf('  1/%-4d   %.6e     %.2f      %.6e     %.2f\n', ...
            J_list(idx), err_L2(idx), order_L2(idx-1), err_Linf(idx), order_Linf(idx-1));
    end
end
fprintf('------------------------------------------------------------------------\n');